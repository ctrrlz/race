#include "game.h"

int main()
{
	Game game;
	game.play();
	return 0;
}
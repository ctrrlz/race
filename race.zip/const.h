#pragma once
const size_t FPS = 60;
const float WINDOW_WIDTH = 528;
const float WINDOW_HEIGHT = 900;
